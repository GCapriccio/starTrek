import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.sound.*; 
import java.util.ArrayList; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class CC_QuadTree4 extends PApplet {

// Daniel Shiffman
// http://codingtra.in
// http://patreon.com/codingtrain
//Videos
//Part 1:
//https://www.youtube.com/watch?v=OJxEcs0w_kE
//Part 2: 
//https://www.youtube.com/watch?v=QQx_NmCIuCY

//This code is only part 1 video of the challenge. 


float w = 0.01f;
float o = 0;
float r = 0;

float a = 10;
float b = 28;
float c = 8.0f / 3.0f;

float high = 0;

//float attackTime = 0.001;
//float sustainTime = 0.004;
//float sustainLevel = 0.3;
//float releaseTime = 0.4;

//PImage cats;

//TriOsc triOsc;
//Env env;

Quadtree qtree;
TriOsc triangle;

public void setup (){
  
  
  
  //cats = loadImage("cat.jpg");
  
  background(0);
  
  float k;
  
  k = (14.791f % 7);
    
  //frameRate(k * 8);

    frameRate(k * 32);

  
  high = high * 0.5f;
  
  triangle = new TriOsc(this);
 
  int man = 600;
 
  triangle.amp(0.06f);
  triangle.freq(man);
  //triangle.play();
 
  //triOsc = new TriOsc(this);
 
  //env = new Env(this); 

//size(400 ,400);
//background(0);

  qtree = new Quadtree (new Rectangle (width/2 , height/2 , width/2 , height/2) , 4);

}

public void draw (){
 
  qtree.show();
  
  gForce();
  
  println(frameCount);
  
  if(mousePressed){
    
    for (int i  = 0 ; i < 5 ; i++){
      
       qtree.insert(new Point ( mouseX +random(-5,5) , mouseY+random(-5,5)));
    
  }
  
}
  
} 
// Daniel Shiffman
// http://codingtra.in
// http://patreon.com/codingtrain
//Videos
//Part 1:
//https://www.youtube.com/watch?v=OJxEcs0w_kE
//Part 2: 
//https://www.youtube.com/watch?v=QQx_NmCIuCY

//This code is only part 1 video of the challenge. 

class Point{
  
 double x;
 double y ;
 
 public Point (double x , double y){
   this.x = x;
   this.y = y;
 }
 
 public double getX(){
   return this.x;
 }
  public double getY(){
   return this.y;
 }
  
}
// Daniel Shiffman
// http://codingtra.in
// http://patreon.com/codingtrain
//Videos
//Part 1:
//https://www.youtube.com/watch?v=OJxEcs0w_kE
//Part 2: 
//https://www.youtube.com/watch?v=QQx_NmCIuCY

//This code is only part 1 video of the challenge. 


class Rectangle {
  
 double x;
 double y;
 double height ; 
 double width;
 
 public Rectangle (double x , double y , double width , double height){
   this.x = x;
   this.y = y;
   this.width = width;
   this.height = height;
 }
 
}
public void onpoint() {
  
  translate((width / 2) + 4.2111f, (height / 2) + 4.0611f);
  rotate(high);
  scale(5);
  stroke(0);
  strokeWeight(0.2f);
  point(w, o);
  
  //triOsc.amp(0.006);
  //triOsc.play();
  //env.play(triOsc, attackTime, sustainTime, sustainLevel, releaseTime);
    
}

public void gForce() {

  float dt = 0.01f;
  float dx = (a * (o - w)) * dt;
  float dy = (w * (b - r) - o) * dt;
  float dz = (w * o - c * r) * dt;
  
  w = w + dx;
  o = o + dy;
  r = r + dz;
  
  high = high + 3;
    
  translate((width / 2) + 3.7f, (height / 2) + 3.7f);
  rotate(high);
  scale(5);
  stroke(color(255, 0, 0));
  strokeWeight(0.2f);
  rect(w, o, 0.01f, 0.01f);
    
}

//int w;

//void draw() {
  
//  //text(frameCount, 50, 10);
    
//  //w = ;
   
//  //background(cats); 
  
//  gForce();
  
//  println(frameCount);
  
//}
// Daniel Shiffman
// http://codingtra.in
// http://patreon.com/codingtrain
//Videos
//Part 1:
//https://www.youtube.com/watch?v=OJxEcs0w_kE
//Part 2: 
//https://www.youtube.com/watch?v=QQx_NmCIuCY

//This code is only part 1 video of the challenge. 



class Quadtree {
    Rectangle boundry;
    int capacity; // max no. of points
    ArrayList <Point> points ;
    boolean divide = false;
    Quadtree northeast; 
      Quadtree northwest;
      Quadtree southeast;
      Quadtree southwest;
    
    public Quadtree (Rectangle rect , int cap){
      this.boundry = rect;
      this.capacity = cap;
      points = new ArrayList<Point>();
    }
    
    public boolean contains (Point p){
     return  p.x <= this.boundry.x+this.boundry.width &&
             p.x >= this.boundry.x-this.boundry.width &&
             p.y <= this.boundry.y+this.boundry.height &&
             p.y >= this.boundry.y-this.boundry.height ;
    }
    
    public boolean insert (Point p){
      if (!this.contains(p)) return false;
      if (this.points.size() < this.capacity ){
      this. points.add(p); 
      return true;
      }
      else {
        if (!this.divide) {
        subDivide();
        }
        if (this.northeast.insert(p)){
         return true; 
        }
        else if (this.northwest.insert(p)){
          return true;
        } 
        else if (this.southeast.insert(p)){
          return true;
        }
        else if(this.southwest.insert(p)){
          return true;
        } 
        else return false;
     }
    }
    public void  subDivide (){
      double x = this.boundry.x;
      double y = this.boundry.y;
      double w = this.boundry.width;
      double h = this.boundry.height;
       this.northeast = new Quadtree(new Rectangle (x+w/2 , y-h/2 , w/2 , h/2),capacity);
      this.northwest = new Quadtree(new Rectangle (x-w/2 , y-h/2 , w/2 , h/2),capacity);
      this.southeast = new Quadtree(new Rectangle (x+w/2 , y+h/2 , w/2 , h/2),capacity);
      this.southwest = new Quadtree(new Rectangle (x-w/2 , y+h/2 , w/2 , h/2),capacity);
      this.divide = true;  
  }
  public void show (){
  stroke(255);
  strokeWeight(1);
  noFill();
  rectMode(CENTER);
  rect ((float)this.boundry.x , (float)this.boundry.y , (float)this.boundry.width *2 , (float)this.boundry.height*2);
  if (this.divide){
   this.northeast.show();
   this.northwest.show();
   this.southeast.show();
   this.southwest.show();
  }
  /* (for showing points)
  for (Point p:points){
    strokeWeight(4);
    point(p.x , p.y);
  }
  */
    
  }
    
    
    
  }
  public void settings() {  size(1041, 781); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#666666", "--stop-color=#cccccc", "CC_QuadTree4" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
